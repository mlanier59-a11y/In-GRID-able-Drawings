# In-GRID-able Drawings Playtest 0.1.101 — DRO Dot Datum Test

Purpose: isolate tile/reference/input/reconstruction alignment with discrete dots and numeric coordinates.

- One touch = one largest-size dot. Dragging does nothing.
- Lines and width choices are disabled.
- Canonical master grid remains on.
- During each served tile the screen shows REF X/Y, MINE X/Y, and ERR dX/dY on a 0–1000 full-picture coordinate scale.
- For a tile containing more than one diagnostic dot, REF follows the source dot nearest the latest tap.
- Use Undo and retry until both errors are reasonably close; <=10 is the working acceptance target, not a scoring rule.
- Press OK only after accepting the displayed coordinates.
- Fresh save namespace for 0.1.101.

The old accuracy scorer remains present only because the playtest shell expects it; its score is not part of this diagnostic.
