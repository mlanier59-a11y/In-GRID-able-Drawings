# In-GRID-able Drawings — Diagnostic 0.1.108

Successive-stroke/boundary state diagnostic based on Diagnostic 0.1.107.

## Test 1 procedure
Follow the on-screen STEP 1 OF 10 instructions exactly. Do not erase any marks.

1. Draw A once, fully contained.
2. Start inside the white tile and cross the RIGHT edge to outside; lift outside.
3. Draw B once, fully contained.
4. Draw C once, fully contained.
5. Draw D once, fully contained.
6. Press UNDO exactly once, then NEXT.
7. Draw E once, fully contained.
8. Again start inside and cross the RIGHT edge to outside; lift outside.
9. Draw F once, fully contained.
10. Draw G once, fully contained, then OK.

Ghost stations A–G are well inside the tile. The two boundary-crossing steps are intentionally retained rather than erased. The purpose is to see whether a boundary violation changes how subsequent completed strokes are retained/rendered, and whether one Undo changes that state.
