# In-GRID-able Drawings — Playtest 0.1.96

## Organic-art scorer graduation test

The calibration diamond is retired. This build replaces it with the first organic Medium-style source: a side-profile elephant on the same canonical 5×5 tile system.

- Variable-width canonical source segments.
- Interior ear and eye detail.
- Fixed deterministic 5×5 shuffle.
- Blank structural cells remain in the overview; gameplay serves meaningful cells only.
- Scorer 1.0 uses the same six gauges: coverage, placement, direction, continuity, width/mass, and B-style reference-relative excess.
- Carries forward the final high-coverage consistency calibration from the diamond tests.
- Developer diagnostics remain visible to one decimal place.
- Fresh 0.1.96 save namespace.

Purpose: test whether the scorer generalizes to curves/organic contours, junctions, interior detail and variable source widths without adding an elephant-specific coefficient.
