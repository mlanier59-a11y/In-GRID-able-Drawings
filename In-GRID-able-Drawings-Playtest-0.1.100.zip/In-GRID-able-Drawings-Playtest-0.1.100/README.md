# In-GRID-able Drawings — Playtest 0.1.100

Datum / alignment isolation build.

- Source is discrete largest-size dots only; no lines.
- One touch places exactly one largest-size dot. Drag/move cannot create a line.
- Three reference dots are centered exactly on the suspicious x=0.400 tile split at the former tree crossing heights.
- Additional dots straddle split lines at a controlled offset and several dots are wholly inside tiles as controls.
- Artwork is still clipped strictly to the real 5x5 tile boundaries.
- The canonical master grid continues through the 14% display/touch buffer exactly as in 0.1.99.
- Width controls are disabled. GRID remains available and defaults ON.
- Fresh 0.1.100 save namespace.

Purpose: cut variables to the bone and determine whether identical canonical dot locations remain aligned through serving, touch storage, and reconstruction.
