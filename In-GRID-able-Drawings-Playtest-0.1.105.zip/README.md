# In-GRID-able Drawings Playtest 0.1.105

Editing-engine torture test.

- Simple two-tile wavy test bar crossing the canonical X=.400 boundary in a constant-width section.
- Thin ends + medium-width middle for width-transition inspection.
- DRAW target is a glowing green hollow circle; ERASE target is a glowing red hollow circle. Ring diameter follows selected width.
- Strict touch ownership: DOWN must begin inside the acquisition buffer. Outside-start gestures stay ignored even if dragged inside. Owned gestures remain owned until UP even if they travel outside.
- CANCEL discards the in-progress gesture rather than committing a partial edit.
- Four independent remembered widths remain available for DRAW and ERASE.
- Undo/Redo/Wipe/OK retained; REDRAW remains physically separated from gameplay OK.
- FINISHING scoring/serialization moved to a background worker; result transition returns to the UI thread.
- Fresh 0.1.105 save namespace.

Suggested torture sequence: draw normally; erase a short internal section; Undo/Redo/Undo; erase near the X=.400 boundary; start an erase inside and travel outside/inside before lifting; then start outside and drag inside (must do nothing), lift, retouch inside and erase normally. Repeat selected actions in DRAW mode.
