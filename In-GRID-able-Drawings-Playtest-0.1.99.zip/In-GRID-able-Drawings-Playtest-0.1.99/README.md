# In-GRID-able Drawings — Playtest 0.1.99

Datum-grid inspection build.

- Keeps the 0.1.98 branching-tree source and Scorer 1.0 unchanged.
- Grid is ON by default and may still be toggled.
- Replaces the per-view Cheater's Grid with one canonical master grid on the full source coordinate system.
- Each served reference/drawing view shows the exact same master-grid cut for that tile.
- Grid continues through the existing 14% working buffer; source artwork remains clipped strictly to the actual tile.
- Reference and drawing grid use the same tile center/datum and transform.
- Fresh 0.1.99 save namespace.

Purpose: inspect whether mating endpoints and player aiming agree across tile boundaries before adding filled artwork.
