# In-GRID-able Drawings — Playtest 0.1.5
Purpose-built vertical slice for phone/tablet playability testing.

## Build
GitHub Actions → **Build In-GRID-able Playtest APK** → Run workflow (or push to main). Download the artifact and install `app-debug.apk`.

## Included
Three 5×5 Medium test runs using the same undisclosed source art; sequential tile workflow; line-width selector; Undo/Redo/Wipe/OK; portrait/landscape; autosave; 0–1000 score; saved result thumbnails; full drawing/original/split/overlay viewer; PNG save to Gallery.

No opening animation, tutorial, account, cloud, ranking, purchases, or Impossible mode in this playtest.


## 0.1.5 focus
- One canonical 5x5 source tile set is used by the jumbled preview and enlarged references.
- Fixed 5x5 shuffle: the same source tile always lands in the same jumbled position.
- Blank source tiles are skipped during play; REMAINS counts only playable tiles.
- 6x6 Cheater's Grid retained with hedge/buffer drawing.
- Line width #3 is mathematically matched to the calibration diamond source stroke.
- Width/Grid controls are kept outside the reference and drawing squares.
- OK is gated so a rapid double-tap cannot skip the next tile.
- Fresh 0.1.5 save namespace prevents 0.1.4 state contamination.
