# In-GRID-able Drawings Playtest 0.1.102 — Blind Repeatability / Operator Study

Purpose: separate human placement tendencies from tile-boundary/reconstruction errors and make the exact test repeatable across multiple operators.

Protocol for every served tile:
1. Place the dot by eye. No coordinates/errors are displayed.
2. The app prompts TRY AGAIN. Press UNDO and place it again.
3. Repeat once more for a total of three attempts.
4. After attempt 3, press OK.

Every attempt is permanently logged before Undo can remove it from the visible drawing. Each record has a monotonically increasing attempt ID, tile, target, target coordinate, measured coordinate, dX/dY, and final status (UNDONE/WIPED/ACCEPTED). The final accepted dot is the third attempt.

Fixture includes three left/right split dots on X=.400 at the previously suspicious tree neighborhoods, two vertical split controls elsewhere, and five deliberately awkward free-field dots between grid lines. The fixture is arranged so each served tile contains only one target portion.

SAVE PNG also exports a diagnostic CSV to Documents/In-GRID-able Drawings. The PNG goes to Pictures/In-GRID-able Drawings. Fresh save namespace for 0.1.102.
