# In-GRID-able Drawings — Diagnostic 0.1.106

Controlled erase/history diagnostic based directly on Playtest 0.1.105.

## Test 1 procedure
1. Start Test 1. The header shows DRAW / ERASE 1 OF 20.
2. Write the displayed number only inside the blue safe box.
3. Erase that number completely without touching the tile edge or lower ghost target.
4. Tap NEXT. Repeat through 20.
5. After 20 is erased, tap FINAL. A blocking warning explains the final step.
6. Draw the lower horizontal ghost target ONCE. Do not erase/redraw/undo/redo it. Tap OK.
7. Inspect MY DRAWING and the score.

Each stored draw/erase stroke carries both its monotonic sequence number and the visible diagnostic cycle (1–20; final target=21), so the visible countdown is correlated with the internal operation log.

The final target is one horizontal line wholly inside the center tile and does not touch any tile boundary. The numbered safe area is separated from the final target.
