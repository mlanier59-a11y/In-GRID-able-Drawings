# In-GRID-able Drawings — Playtest 0.1.2.2
Purpose-built vertical slice for phone/tablet playability testing.

## Build
GitHub Actions → **Build In-GRID-able Playtest APK** → Run workflow (or push to main). Download the artifact and install `app-debug.apk`.

## Included
Three 5×5 Medium test runs using the same undisclosed source art; sequential tile workflow; line-width selector; Undo/Redo/Wipe/OK; portrait/landscape; autosave; 0–1000 score; saved result thumbnails; full drawing/original/split/overlay viewer; PNG save to Gallery.

No opening animation, tutorial, account, cloud, ranking, purchases, or Impossible mode in this playtest.
