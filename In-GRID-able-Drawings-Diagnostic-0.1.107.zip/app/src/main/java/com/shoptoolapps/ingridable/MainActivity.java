package com.shoptoolapps.ingridable;

import android.app.*;import android.os.*;import android.content.*;import android.content.res.Configuration;import android.graphics.*;import android.graphics.drawable.*;import android.net.Uri;import android.provider.MediaStore;import android.view.*;import android.widget.*;import org.json.*;import java.io.*;import java.util.*;

public class MainActivity extends Activity{
 GameView game;
 @Override public void onCreate(Bundle b){super.onCreate(b);game=new GameView(this);setContentView(game);}
 @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);game.invalidate();}
}
class Pt{float x,y;Pt(float X,float Y){x=X;y=Y;}}
class Stroke{int tile;float w;boolean erase=false;long seq=0;int cycle=0;ArrayList<Pt> p=new ArrayList<>();Stroke(int t,float W){tile=t;w=W;}}

class GameView extends View{
 Paint p=new Paint(3); Paint line=new Paint(3); final int PAPER=Color.rgb(250,246,232),WOOD=Color.rgb(112,76,49),DARKWOOD=Color.rgb(65,43,31),INK=Color.rgb(28,48,86);
 ArrayList<Stroke>[] done=new ArrayList[25]; ArrayList<Stroke> redo=new ArrayList<>(); Stroke active;
 RectF[] controlHit=new RectF[]{new RectF(),new RectF(),new RectF(),new RectF()}; RectF[] widthHit=new RectF[]{new RectF(),new RectF(),new RectF(),new RectF()};
 RectF gridHit=new RectF(), exitHit=new RectF(), drawBuffer=new RectF(), toolDrawHit=new RectF(),toolEraseHit=new RectF(); boolean gridOn=true,eraseMode=false; int insetBottom=0; boolean gestureOwned=false; float cursorX=0,cursorY=0;
 int screen=0,test=1,tile=0; int diagCycle=1; boolean diagFinal=false; float widthChoice=.075f,drawWidth=.075f,eraseWidth=.075f; long okLockedUntil=0,resultLockedUntil=0,nextSeq=1; boolean okNeedsRelease=false; boolean started=false;
 int viewerPress=-1; // 0 back, 1 save, 2 redraw; command is owned from DOWN through UP
 RectF ref=new RectF(),draw=new RectF(); SharedPreferences sp; int[] shuffle={12,3,21,7,0,18,5,24,10,1,16,9,22,4,14,6,20,11,2,23,8,17,13,19,15}; int[] playable=buildPlayable();
 GameView(Context c){super(c);setBackgroundColor(PAPER);sp=c.getSharedPreferences("playtest0107boundarydiag",0);for(int i=0;i<25;i++)done[i]=new ArrayList<>();setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
 @Override public WindowInsets onApplyWindowInsets(WindowInsets wi){insetBottom=wi.getSystemWindowInsetBottom();invalidate();return wi;}
 void text(Canvas c,String s,float x,float y,float z,Paint.Align a){p.setColor(DARKWOOD);p.setTextSize(z);p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextAlign(a);c.drawText(s,x,y,p);}
 @Override protected void onDraw(Canvas c){super.onDraw(c); if(screen==0)library(c); else if(screen==1)play(c); else if(screen==3)finishing(c); else viewer(c);}
 void library(Canvas c){float w=getWidth(),h=getHeight();c.drawColor(PAPER);p.setColor(WOOD);c.drawRect(0,0,w,h*.13f,p);text(c,"In-GRID-able Drawings",w/2,h*.075f,h*.034f,Paint.Align.CENTER);text(c,"DIAGNOSTIC 0.1.107 — BOUNDARY DIRECTION TEST",w/2,h*.112f,h*.018f,Paint.Align.CENTER);float top=h*.18f,cardH=h*.20f;
  for(int i=1;i<=3;i++){float y=top+(i-1)*(cardH+h*.035f);p.setColor(Color.WHITE);c.drawRoundRect(w*.08f,y,w*.92f,y+cardH,18,18,p);text(c,"TEST "+i,w*.14f,y+cardH*.22f,h*.025f,Paint.Align.LEFT);for(int k=0;k<i;k++){p.setColor(Color.BLACK);c.drawRect(w*.14f+k*h*.028f,y+cardH*.34f,w*.14f+k*h*.028f+h*.018f,y+cardH*.34f+h*.018f,p);}String saved=sp.getString("result"+i,null); if(saved==null) text(c,"Tap to draw",w*.14f,y+cardH*.78f,h*.022f,Paint.Align.LEFT); else {try{JSONObject j=new JSONObject(saved);text(c,"Finished   Accuracy "+j.getInt("score")+" / 1000",w*.14f,y+cardH*.78f,h*.022f,Paint.Align.LEFT);drawThumb(c,j,w*.68f,y+cardH*.12f,cardH*.76f);}catch(Exception e){}}
  }
 }
 void drawThumb(Canvas c,JSONObject j,float x,float y,float s)throws Exception{p.setColor(PAPER);c.drawRect(x,y,x+s,y+s,p);JSONArray a=j.getJSONArray("strokes");drawStored(c,a,new RectF(x,y,x+s,y+s),Color.rgb(35,72,140));}
 void play(Canvas c){float w=getWidth(),h=getHeight();boolean land=w>h;c.drawColor(PAPER);float rail=land?h*.12f:h*.09f;p.setColor(WOOD);c.drawRect(0,0,w,rail,p);text(c,(test==1? (diagFinal?"FINAL TARGET — ONE DRAW ONLY":"DRAW / ERASE "+diagCycle+" OF 20") : "TEST "+test+"   REMAINS "+remaining()),w*.04f,rail*.62f,rail*.30f,Paint.Align.LEFT);for(int k=0;k<test;k++){p.setColor(Color.BLACK);c.drawRect(w*.72f+k*rail*.28f,rail*.30f,w*.72f+k*rail*.28f+rail*.18f,rail*.48f,p);}float bottom=h-insetBottom;float controlTop=bottom-Math.max(h*.10f,70);if(land){float top=rail+h*.025f;float availH=controlTop-top-h*.025f;float side=Math.min(availH,w*.39f);float cy=(top+controlTop-h*.025f)/2f;ref.set(w*.025f,cy-side/2,w*.025f+side,cy+side/2);draw.set(w*.975f-side,cy-side/2,w*.975f,cy+side/2);}else{float gap=h*.105f;float top=rail+h*.020f;float availH=controlTop-top-gap-h*.015f;float side=Math.min(w*.82f,(availH-gap)/2f);float left=(w-side)/2f;ref.set(left,top,left+side,top+side);draw.set(left,top+side+gap,left+side,top+side+gap+side);}float buf=draw.width()*.14f;drawBuffer.set(draw.left-buf,draw.top-buf,draw.right+buf,draw.bottom+buf);exitHit.set(w*.91f,rail*.12f,w*.985f,rail*.88f);p.setColor(Color.WHITE);c.drawRect(ref,p);c.drawRect(draw,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(WOOD);c.drawRect(ref,p);c.drawRect(draw,p);p.setStyle(Paint.Style.FILL);button(c,exitHit,"X");
  if(!started){drawScrambled(c,ref);RectF st=land?new RectF(w*.455f,h*.44f,w*.545f,h*.54f):new RectF(w*.34f,ref.bottom+h*.008f,w*.66f,draw.top-h*.008f);button(c,st,"START");}else{drawSourceTile(c,ref,tile);drawCurrent(c,draw,tile);if(test==1)drawDiagnosticOverlay(c,draw);drawToolTarget(c);if(gridOn){drawMasterGridWindow(c,ref,tile);drawMasterGridWindow(c,draw,tile);}controls(c);text(c,eraseMode?"ERASE: red target":"DRAW: green target",w*.98f,controlTop-h*.010f,h*.015f,Paint.Align.RIGHT);}
 }
 void drawScrambled(Canvas c,RectF r){float s=Math.min(r.width(),r.height()),ox=r.centerX()-s/2,oy=r.centerY()-s/2,cs=s/5;for(int pos=0;pos<25;pos++){int src=shuffle[pos];RectF dst=new RectF(ox+(pos%5)*cs,oy+(pos/5)*cs,ox+(pos%5+1)*cs,oy+(pos/5+1)*cs);drawCanonicalTile(c,dst,src);}p.setStyle(Paint.Style.STROKE);p.setColor(Color.rgb(210,200,180));p.setStrokeWidth(1);for(int i=0;i<=5;i++){c.drawLine(ox+i*cs,oy,ox+i*cs,oy+s,p);c.drawLine(ox,oy+i*cs,ox+s,oy+i*cs,p);}p.setStyle(Paint.Style.FILL);}
 void drawCanonicalTile(Canvas c,RectF dst,int t){c.save();c.clipRect(dst);float tw=dst.width(),th=dst.height();RectF full=new RectF(dst.left-(t%5)*tw,dst.top-(t/5)*th,dst.left-(t%5)*tw+tw*5,dst.top-(t/5)*th+th*5);drawSource(c,full,Color.BLACK);c.restore();}
 void drawSourceTile(Canvas c,RectF r,int t){float z=Math.min(r.width(),r.height());RectF sq=new RectF(r.centerX()-z/2,r.centerY()-z/2,r.centerX()+z/2,r.centerY()+z/2);drawCanonicalTile(c,sq,t);}
 void drawSource(Canvas c,RectF r,int color){
  // Bird + branch source: solid-looking masses plus thin linework; scorer remains unchanged.
  line.setColor(color);line.setStyle(Paint.Style.STROKE);line.setStrokeCap(Paint.Cap.ROUND);line.setStrokeJoin(Paint.Join.ROUND);
  for(float[] g:SRC){line.setStrokeWidth(r.width()*g[4]);c.drawLine(r.left+r.width()*g[0],r.top+r.height()*g[1],r.left+r.width()*g[2],r.top+r.height()*g[3],line);}
 }
 void drawCurrent(Canvas c,RectF r,int t){
  int W=Math.max(320,(int)r.width());Bitmap bm=Bitmap.createBitmap(W,W,Bitmap.Config.ARGB_8888);Canvas bc=new Canvas(bm);
  for(Stroke s:done[t])drawOp(bc,s,new RectF(0,0,W,W),INK);if(active!=null)drawOp(bc,active,new RectF(0,0,W,W),INK);c.drawBitmap(bm,null,r,p);
 }
 void drawOp(Canvas c,Stroke s,RectF r,int col){if(!s.erase){drawStroke(c,s,r,col);return;}if(s.p.size()<1)return;line.setStyle(Paint.Style.STROKE);line.setStrokeCap(Paint.Cap.ROUND);line.setStrokeJoin(Paint.Join.ROUND);line.setStrokeWidth(Math.max(2,s.w*r.width()));line.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));Path q=new Path();Pt a=s.p.get(0);q.moveTo(r.left+a.x*r.width(),r.top+a.y*r.height());for(int i=1;i<s.p.size();i++){a=s.p.get(i);q.lineTo(r.left+a.x*r.width(),r.top+a.y*r.height());}if(s.p.size()==1)c.drawPoint(r.left+a.x*r.width(),r.top+a.y*r.height(),line);else c.drawPath(q,line);line.setXfermode(null);line.setStyle(Paint.Style.FILL);}

 void drawStroke(Canvas c,Stroke s,RectF r,int col){if(s.p.size()<1)return;c.save();c.clipRect(r);line.setColor(col);line.setStyle(Paint.Style.STROKE);line.setStrokeCap(Paint.Cap.ROUND);line.setStrokeJoin(Paint.Join.ROUND);line.setStrokeWidth(Math.max(2,s.w*r.width()));Path q=new Path();Pt a=s.p.get(0);q.moveTo(r.left+a.x*r.width(),r.top+a.y*r.height());for(int i=1;i<s.p.size();i++){a=s.p.get(i);q.lineTo(r.left+a.x*r.width(),r.top+a.y*r.height());}if(s.p.size()==1)c.drawPoint(r.left+a.x*r.width(),r.top+a.y*r.height(),line);else c.drawPath(q,line);line.setStyle(Paint.Style.FILL);c.restore();}
 void drawToolTarget(Canvas c){
  if(!gestureOwned||active==null)return;
  float rad=Math.max(8f,widthChoice*draw.width()*.50f);
  p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(3f,rad*.18f));
  p.setColor(eraseMode?Color.rgb(230,45,45):Color.rgb(35,205,80));
  p.setShadowLayer(Math.max(7f,rad*.55f),0,0,p.getColor());
  c.drawCircle(cursorX,cursorY,rad,p);
  p.clearShadowLayer();p.setStyle(Paint.Style.FILL);
 }
 void controls(Canvas c){float w=getWidth(),h=getHeight();boolean land=w>h;float bottom=h-insetBottom;float barH=Math.max(h*.10f,70);float top=bottom-barH;p.setColor(WOOD);c.drawRect(0,top,w,bottom,p);String[] a={"UNDO","REDO","WIPE",(test==1&&!diagFinal?(diagCycle<20?"NEXT":"FINAL") : "OK")};for(int i=0;i<4;i++){controlHit[i].set(w*(.02f+i*.245f),top+barH*.12f,w*(.235f+i*.245f),bottom-barH*.12f);button(c,controlHit[i],a[i]);} toolDrawHit.set(w*.02f,top-barH*.62f,w*.18f,top-barH*.10f);toolEraseHit.set(w*.20f,top-barH*.62f,w*.38f,top-barH*.10f);button(c,toolDrawHit,eraseMode?"DRAW":"DRAW ✓");button(c,toolEraseHit,eraseMode?"ERASE ✓":"ERASE");
  float[] ws={.020f,.040f,.075f,.120f};if(land){float cx=w*.50f,cy=(ref.top+ref.bottom)/2f;float step=Math.min(h*.11f,ref.height()*.18f);for(int i=0;i<4;i++){float yy=cy+(i-1.5f)*step;widthHit[i].set(cx-w*.035f,yy-step*.35f,cx+w*.035f,yy+step*.35f);p.setColor(i==widthIndex()?Color.rgb(245,220,160):WOOD);c.drawCircle(cx,yy,Math.min(w*.018f,step*.25f),p);line.setColor(DARKWOOD);line.setStrokeWidth(Math.max(2,ws[i]*draw.width()));c.drawLine(cx-w*.020f,yy,cx+w*.020f,yy,line);}gridHit.set(w*.455f,ref.bottom-h*.075f,w*.545f,ref.bottom-h*.015f);}else{float cy=(ref.bottom+draw.top)/2f;float step=w*.105f;float first=w*.32f;for(int i=0;i<4;i++){float xx=first+i*step;widthHit[i].set(xx-step*.38f,cy-h*.025f,xx+step*.38f,cy+h*.025f);p.setColor(i==widthIndex()?Color.rgb(245,220,160):WOOD);c.drawCircle(xx,cy,Math.min(w*.020f,h*.018f),p);line.setColor(DARKWOOD);line.setStrokeWidth(Math.max(2,ws[i]*draw.width()));c.drawLine(xx-w*.025f,cy,xx+w*.025f,cy,line);}gridHit.set(w*.04f,cy-h*.030f,w*.22f,cy+h*.030f);}button(c,gridHit,gridOn?"GRID ON":"GRID");}
 void drawMasterGridWindow(Canvas c,RectF tileRect,int t){
  // ONE canonical grid lives on the full 5x5 source image: 30 x 30 divisions,
  // i.e. six measuring divisions per puzzle tile.  We never regenerate/recenter
  // a tile grid.  We transform the master grid through the exact same tile datum
  // and merely show a 14% larger window around the 10x10-equivalent tile.
  // Artwork remains clipped strictly to tileRect; only the grid enters the buffer.
  final int MASTER_DIV=30; final float BUF=.14f;
  float tw=tileRect.width(), th=tileRect.height();
  RectF win=new RectF(tileRect); win.inset(-tw*BUF,-th*BUF);
  int col=t%5,row=t/5;
  float fullLeft=tileRect.left-col*tw, fullTop=tileRect.top-row*th;
  float fullW=tw*5f, fullH=th*5f;
  c.save(); c.clipRect(win);
  p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.35f);p.setColor(Color.argb(82,60,105,150));
  for(int i=0;i<=MASTER_DIV;i++){
   float x=fullLeft+fullW*i/MASTER_DIV; if(x>=win.left-2&&x<=win.right+2)c.drawLine(x,win.top,x,win.bottom,p);
   float y=fullTop+fullH*i/MASTER_DIV; if(y>=win.top-2&&y<=win.bottom+2)c.drawLine(win.left,y,win.right,y,p);
  }
  // Actual tile boundary is the datum/cut line.  The grid continues beyond it; artwork does not.
  p.setStrokeWidth(2.0f);p.setColor(Color.argb(105,60,105,150));c.drawRect(tileRect,p);
  p.setStyle(Paint.Style.FILL);c.restore();
 }
 void drawDiagnosticOverlay(Canvas c,RectF r){
  // Ghost target: never part of the stored drawing. It is intentionally isolated in the lower third.
  float y=r.top+r.height()*.72f,x1=r.left+r.width()*.22f,x2=r.left+r.width()*.78f;
  p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(3f,r.width()*.012f));p.setColor(Color.argb(120,120,120,120));
  c.drawLine(x1,y,x2,y,p);
  // Safe number-writing box: upper half, comfortably inside all tile boundaries and away from target.
  p.setStrokeWidth(2f);p.setColor(Color.argb(90,80,120,160));RectF safe=new RectF(r.left+r.width()*.18f,r.top+r.height()*.12f,r.right-r.width()*.18f,r.top+r.height()*.52f);c.drawRect(safe,p);p.setStyle(Paint.Style.FILL);
  String special=specialInstruction(diagCycle);
  if(diagFinal) text(c,"DRAW FINAL LINE ON GHOST — ONCE",r.centerX(),r.top+r.height()*.08f,Math.max(14f,r.height()*.040f),Paint.Align.CENTER);
  else if(special!=null){
   text(c,"SPECIAL CYCLE "+diagCycle,r.centerX(),r.top+r.height()*.065f,Math.max(15f,r.height()*.040f),Paint.Align.CENTER);
   text(c,special,r.centerX(),r.top+r.height()*.105f,Math.max(13f,r.height()*.031f),Paint.Align.CENTER);
  } else text(c,"WRITE "+diagCycle+" HERE • ERASE IT • TAP "+(diagCycle<20?"NEXT":"FINAL"),r.centerX(),r.top+r.height()*.08f,Math.max(14f,r.height()*.040f),Paint.Align.CENTER);
 }
 String specialInstruction(int n){
  switch(n){
   case 5:return "LEFT EDGE: START INSIDE → CROSS OUTSIDE";
   case 8:return "LEFT EDGE: START OUTSIDE → CROSS INSIDE";
   case 11:return "RIGHT EDGE: START INSIDE → CROSS OUTSIDE";
   case 14:return "RIGHT EDGE: START OUTSIDE → CROSS INSIDE";
   case 17:return "TOP EDGE: START INSIDE → CROSS OUTSIDE";
   case 18:return "TOP EDGE: START OUTSIDE → CROSS INSIDE";
   case 19:return "BOTTOM EDGE: START INSIDE → CROSS OUTSIDE";
   case 20:return "BOTTOM EDGE: START OUTSIDE → CROSS INSIDE";
  }return null;
 }
 void showSpecialCycleWarningIfNeeded(){
  String s=specialInstruction(diagCycle);if(s==null)return;
  String dir=s.contains("START INSIDE")?"Start your finger INSIDE the white tile, then draw across the named edge to OUTSIDE the white tile.":"Start your finger OUTSIDE the white tile but inside the visible grid/buffer, then draw across the named edge INTO the white tile.";
  new AlertDialog.Builder(getContext()).setTitle("SPECIAL BOUNDARY TEST — CYCLE "+diagCycle)
   .setMessage(s+"\n\n"+dir+"\n\nAfter making the boundary-crossing mark, erase it normally. Then tap NEXT. Do not use Undo or Wipe.")
   .setCancelable(false).setPositiveButton("BEGIN CYCLE "+diagCycle,(d,w)->invalidate()).show();
 }
 void showFinalDiagnosticWarning(){
  new AlertDialog.Builder(getContext()).setTitle("20 ERASE CYCLES COMPLETE")
   .setMessage("Before continuing, make sure 20 is completely erased.\n\nNext: draw ONE horizontal line over the ghost target in the lower third. Close enough is good enough.\n\nDo not erase, redraw, undo, or redo the final line. Then tap OK.")
   .setCancelable(false).setPositiveButton("CONTINUE TO FINAL",(d,w)->{diagFinal=true;eraseMode=false;widthChoice=drawWidth;saveProgress();invalidate();}).show();
 }
 int widthIndex(){float[] a={.020f,.040f,.075f,.120f};int best=0;for(int i=1;i<4;i++)if(Math.abs(a[i]-widthChoice)<Math.abs(a[best]-widthChoice))best=i;return best;}
 void button(Canvas c,RectF r,String s){p.setColor(DARKWOOD);c.drawRoundRect(r,12,12,p);p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(r.height()*.38f);c.drawText(s,r.centerX(),r.centerY()+r.height()*.14f,p);}
 @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();int action=e.getActionMasked();if(action==MotionEvent.ACTION_UP&&okNeedsRelease&&SystemClock.uptimeMillis()>=okLockedUntil)okNeedsRelease=false;if(screen==0&&action==MotionEvent.ACTION_UP){float top=h*.18f,cardH=h*.20f;for(int i=1;i<=3;i++){float yy=top+(i-1)*(cardH+h*.035f);if(y>=yy&&y<=yy+cardH){test=i;if(sp.contains("result"+i)){screen=2;}else{resetPlay();screen=1;}invalidate();return true;}}}
  else if(screen==1){if(action==MotionEvent.ACTION_UP&&exitHit.contains(x,y)){saveProgress();((Activity)getContext()).finishAndRemoveTask();return true;}if(!started&&action==MotionEvent.ACTION_UP&&startTouchHit(x,y)){started=true;tile=playable[0];okLockedUntil=SystemClock.uptimeMillis()+350;okNeedsRelease=true;saveProgress();invalidate();return true;}if(started){if(action==MotionEvent.ACTION_UP&&gridHit.contains(x,y)){gridOn=!gridOn;invalidate();return true;}if(action==MotionEvent.ACTION_UP&&toolDrawHit.contains(x,y)){eraseMode=false;widthChoice=drawWidth;invalidate();return true;}if(action==MotionEvent.ACTION_UP&&toolEraseHit.contains(x,y)){eraseMode=true;widthChoice=eraseWidth;invalidate();return true;}if(action==MotionEvent.ACTION_UP){for(int i=0;i<4;i++)if(widthHit[i].contains(x,y)){widthChoice=new float[]{.020f,.040f,.075f,.120f}[i];if(eraseMode)eraseWidth=widthChoice;else drawWidth=widthChoice;invalidate();return true;}for(int i=0;i<4;i++)if(controlHit[i].contains(x,y)){if(i==0&&done[tile].size()>0){redo.add(done[tile].remove(done[tile].size()-1));saveProgress();}else if(i==1&&redo.size()>0){done[tile].add(redo.remove(redo.size()-1));saveProgress();}else if(i==2){done[tile].clear();redo.clear();active=null;saveProgress();}else if(i==3){if(!okNeedsRelease&&SystemClock.uptimeMillis()>=okLockedUntil){active=null;if(test==1&&!diagFinal){if(diagCycle<20){diagCycle++;saveProgress();showSpecialCycleWarningIfNeeded();}else{showFinalDiagnosticWarning();}}else commitTile();}}invalidate();return true;}}
   if(action==MotionEvent.ACTION_DOWN){
    // Strict ownership: only a DOWN inside the acquisition buffer can own a draw/erase gesture.
    // An outside DOWN stays ignored for its entire lifetime even if it later moves inside.
    if(drawBuffer.contains(x,y)){float nx=(x-draw.left)/draw.width(),ny=(y-draw.top)/draw.height();active=new Stroke(tile,widthChoice);active.erase=eraseMode;active.seq=nextSeq++;active.cycle=(test==1?(diagFinal?21:diagCycle):0);active.p.add(new Pt(nx,ny));gestureOwned=true;cursorX=x;cursorY=y;getParent().requestDisallowInterceptTouchEvent(true);invalidate();return true;}
    gestureOwned=false;active=null;return true;
   }
   if(gestureOwned&&active!=null&&(action==MotionEvent.ACTION_MOVE||action==MotionEvent.ACTION_UP)){float nx=(x-draw.left)/draw.width(),ny=(y-draw.top)/draw.height();active.p.add(new Pt(nx,ny));cursorX=x;cursorY=y;if(action==MotionEvent.ACTION_UP){done[tile].add(active);active=null;gestureOwned=false;redo.clear();saveProgress();getParent().requestDisallowInterceptTouchEvent(false);}invalidate();return true;}
   if(action==MotionEvent.ACTION_CANCEL){active=null;gestureOwned=false;getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;}
   // MOVE/UP belonging to an outside-start gesture are intentionally ignored.
   if(!gestureOwned&&(action==MotionEvent.ACTION_MOVE||action==MotionEvent.ACTION_UP))return true;
   }
  } else if(screen==2){
   // Result-screen commands are captured on ACTION_DOWN and only that captured command may
   // fire on ACTION_UP.  The buttons also sit above the gameplay OK row, so a rapid second
   // tap at the old OK location lands in dead space instead of becoming REDRAW.
   RectF vb0=new RectF(w*.05f,h*.86f,w*.34f,h*.93f),vb1=new RectF(w*.39f,h*.86f,w*.68f,h*.93f),vb2=new RectF(w*.73f,h*.105f,w*.96f,h*.165f); if(SystemClock.uptimeMillis()<resultLockedUntil){viewerPress=-1;return true;}
   if(action==MotionEvent.ACTION_DOWN){viewerPress=vb0.contains(x,y)?0:vb1.contains(x,y)?1:vb2.contains(x,y)?2:-1;return true;}
   if(action==MotionEvent.ACTION_CANCEL){viewerPress=-1;return true;}
   if(action==MotionEvent.ACTION_UP){int cmd=viewerPress;viewerPress=-1;if(cmd==0&&vb0.contains(x,y)){screen=0;invalidate();return true;}if(cmd==1&&vb1.contains(x,y)){exportResult();invalidate();return true;}if(cmd==2&&vb2.contains(x,y)){resetPlay();screen=1;invalidate();return true;}if(y<h*.82f){viewMode=(viewMode+1)%4;invalidate();}return true;}
  }return true;}
 boolean startTouchHit(float x,float y){float w=getWidth(),h=getHeight();boolean land=w>h;if(land)return x>w*.455f&&x<w*.545f&&y>h*.40f&&y<h*.58f;return x>w*.34f&&x<w*.66f&&y>ref.bottom&&y<draw.top;}
 void resetPlay(){tile=playable[0];diagCycle=1;diagFinal=false;started=false;active=null;gestureOwned=false;redo.clear();for(int i=0;i<25;i++)done[i].clear();loadProgress();}
 int[] buildPlayable(){
  // One authoritative playable-tile list.  A tile qualifies by meaningful SOURCE CENTERLINE
  // length, not by raster antialiasing/line-width bleed into a neighboring cell.  This keeps
  // tiny edge nicks from becoming blank-looking chores.
  float[] len=new float[25];
  for(float[] g:SRC){float L=(float)Math.hypot(g[2]-g[0],g[3]-g[1]);int n=Math.max(80,(int)(L*2000));
   for(int j=0;j<n;j++){float f=(j+.5f)/n,x=g[0]+(g[2]-g[0])*f,y=g[1]+(g[3]-g[1])*f;int col=Math.max(0,Math.min(4,(int)(x*5))),row=Math.max(0,Math.min(4,(int)(y*5)));len[row*5+col]+=L/n;}
  }
  ArrayList<Integer> a=new ArrayList<>();for(int t=0;t<25;t++)if(len[t]>=.015f)a.add(t);
  int[] out=new int[a.size()];for(int i=0;i<a.size();i++)out[i]=a.get(i);return out;
 }
 int playableIndex(int t){for(int i=0;i<playable.length;i++)if(playable[i]==t)return i;return -1;}
 int remaining(){int i=playableIndex(tile);return started&&i>=0?playable.length-i:playable.length;}
 void commitTile(){active=null;redo.clear();int i=playableIndex(tile);if(i>=0&&i<playable.length-1){tile=playable[i+1];okLockedUntil=SystemClock.uptimeMillis()+500;okNeedsRelease=true;saveProgress();}else beginFinish();}

 void beginFinish(){
  active=null;gestureOwned=false;redo.clear();screen=3;invalidate();
  // Heavy scoring/serialization runs off the UI thread so Android stays responsive.
  final ArrayList<Stroke>[] snapshot=copyDone();
  new Thread(new Runnable(){public void run(){
   final FinishData fd=computeFinish(snapshot);
   post(new Runnable(){public void run(){applyFinish(fd);invalidate();}});
  }},"InGRID-finish").start();
 }
 @SuppressWarnings("unchecked") ArrayList<Stroke>[] copyDone(){ArrayList<Stroke>[] out=new ArrayList[25];for(int t=0;t<25;t++){out[t]=new ArrayList<>();for(Stroke s:done[t]){Stroke n=new Stroke(s.tile,s.w);n.erase=s.erase;n.seq=s.seq;n.cycle=s.cycle;for(Pt q:s.p)n.p.add(new Pt(q.x,q.y));out[t].add(n);}}return out;}
 static class FinishData{String json;FinishData(String s){json=s;}}
 FinishData computeFinish(ArrayList<Stroke>[] snap){ArrayList<Stroke>[] live=done;done=snap;try{int sc=score();JSONObject j=serialize(true,sc);j.put("scorer","1.0-vector-erase-aware");j.put("diag",lastDiag);return new FinishData(j.toString());}catch(Exception e){return new FinishData(null);}finally{done=live;}}
 void applyFinish(FinishData fd){if(fd.json!=null)sp.edit().putString("result"+test,fd.json).remove("progress"+test).apply();screen=2;viewMode=1;resultLockedUntil=SystemClock.uptimeMillis()+900;}
 void finishing(Canvas c){c.drawColor(PAPER);float w=getWidth(),h=getHeight();text(c,"FINISHING…",w/2,h*.46f,h*.040f,Paint.Align.CENTER);text(c,"Scoring and saving your drawing",w/2,h*.52f,h*.020f,Paint.Align.CENTER);}
 void saveProgress(){try{JSONObject j=serialize(false,0);j.put("tile",tile);j.put("started",started);j.put("diagCycle",diagCycle);j.put("diagFinal",diagFinal);sp.edit().putString("progress"+test,j.toString()).apply();}catch(Exception e){}}
 void loadProgress(){String s=sp.getString("progress"+test,null);if(s==null)return;try{JSONObject j=new JSONObject(s);tile=j.getInt("tile");started=j.getBoolean("started");diagCycle=j.optInt("diagCycle",1);diagFinal=j.optBoolean("diagFinal",false);loadStrokes(j.getJSONArray("strokes"));}catch(Exception e){}}
 JSONObject serialize(boolean all,int score)throws Exception{JSONObject j=new JSONObject();j.put("score",score);JSONArray a=new JSONArray();for(int t=0;t<25;t++)for(Stroke s:done[t]){JSONObject o=new JSONObject();o.put("t",t);o.put("w",s.w);o.put("erase",s.erase);o.put("seq",s.seq);o.put("cycle",s.cycle);JSONArray pts=new JSONArray();for(Pt q:s.p){JSONArray v=new JSONArray();v.put(q.x);v.put(q.y);pts.put(v);}o.put("p",pts);a.put(o);}j.put("strokes",a);return j;}
 void loadStrokes(JSONArray a)throws Exception{for(int i=0;i<25;i++)done[i].clear();for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Stroke s=new Stroke(o.getInt("t"),(float)o.getDouble("w"));s.erase=o.optBoolean("erase",false);s.seq=o.optLong("seq",nextSeq++);s.cycle=o.optInt("cycle",0);nextSeq=Math.max(nextSeq,s.seq+1);JSONArray pts=o.getJSONArray("p");for(int k=0;k<pts.length();k++){JSONArray v=pts.getJSONArray(k);s.p.add(new Pt((float)v.getDouble(0),(float)v.getDouble(1)));}done[s.tile].add(s);}}
 // Canonical bird/branch source: x1,y1,x2,y2,sourceWidth.
 // Broad overlapping centerlines create solid-looking source masses without changing Scorer 1.0.
 static final float[][] SRC={
  // 0.1.107 DIAGNOSTIC: one simple horizontal target, wholly inside center tile (tile 12).
  // In tile-local coordinates it runs x=.22..78 at y=.72 (lower third), far from every edge.
  {.444f,.544f,.556f,.544f,.030f}
 };
 int score(){
  ArrayList<float[]> segs=new ArrayList<>();float userArea=0f,excessArea=0f;
  for(int t=0;t<25;t++)for(int si=0;si<done[t].size();si++){Stroke st=done[t].get(si);if(st.erase)continue;
   float ox=(t%5)/5f,oy=(t/5)/5f,sw=st.w/5f;
   if(st.p.size()==1){Pt q=st.p.get(0);if(erasedByLater(t,si,q.x,q.y))continue;float x=ox+q.x/5f,y=oy+q.y/5f;segs.add(new float[]{x,y,x,y,sw});userArea+=3.14159f*sw*sw*.25f;continue;}
   for(int i=1;i<st.p.size();i++){Pt a=st.p.get(i-1),b=st.p.get(i);float localLen=(float)Math.hypot(b.x-a.x,b.y-a.y);int parts=Math.max(1,(int)Math.ceil(localLen/.012f));for(int m=0;m<parts;m++){float f1=m/(float)parts,f2=(m+1)/(float)parts,fm=(f1+f2)*.5f,lx=a.x+(b.x-a.x)*fm,ly=a.y+(b.y-a.y)*fm;if(erasedByLater(t,si,lx,ly))continue;float ax=a.x+(b.x-a.x)*f1,ay=a.y+(b.y-a.y)*f1,bx=a.x+(b.x-a.x)*f2,by=a.y+(b.y-a.y)*f2;float x1=ox+ax/5f,y1=oy+ay/5f,x2=ox+bx/5f,y2=oy+by/5f;float len=(float)Math.hypot(x2-x1,y2-y1);if(len<.00015f)continue;segs.add(new float[]{x1,y1,x2,y2,sw});userArea+=len*sw;float mx=(x1+x2)*.5f,my=(y1+y2)*.5f;if(sourceDistance(mx,my)>.030f)excessArea+=len*sw;}}
  }
  if(segs.size()==0){lastDiag="COV 0  PLC 0  DIR 0  CON 0  WID 0  EX 0";return 0;}
  float totalLen=0f,refArea=0f;for(float[] g:SRC){float len=(float)Math.hypot(g[2]-g[0],g[3]-g[1]);totalLen+=len;refArea+=len*g[4];}
  final int S=1800;boolean[] hit=new boolean[S];int covered=0;float placeSum=0f,dirSum=0f;int cursor=0;
  for(float[] src:SRC){float slen=(float)Math.hypot(src[2]-src[0],src[3]-src[1]);int n=Math.max(2,Math.round(S*slen/totalLen));
   for(int j=0;j<n;j++){float f=(j+.5f)/n,x=src[0]+(src[2]-src[0])*f,y=src[1]+(src[3]-src[1])*f,best=99f,bdir=0f;
    for(float[] g:segs){float d=pointSegDist(x,y,g[0],g[1],g[2],g[3]);if(d<best){best=d;float sx=src[2]-src[0],sy=src[3]-src[1],gx=g[2]-g[0],gy=g[3]-g[1];float gl=(float)Math.hypot(gx,gy);bdir=gl<.0001f?0f:Math.abs((sx*gx+sy*gy)/(slen*gl));}}
    float pc=best<=.004f?1f:Math.max(0f,1f-(best-.004f)/.030f);placeSum+=pc;if(best<=.022f){covered++;dirSum+=bdir;}if(cursor<hit.length)hit[cursor]=best<=.022f;cursor++;
   }
  }
  int samples=Math.max(1,cursor);float coverage=covered/(float)samples,placement=placeSum/samples,direction=covered==0?0:dirSum/covered;
  int transitions=0;for(int i=1;i<samples&&i<hit.length;i++)if(hit[i]!=hit[i-1])transitions++;float continuity=coverage*(float)Math.exp(-transitions/24f);
  float areaRatio=userArea/Math.max(.0001f,refArea);float widthMass=(float)Math.exp(-Math.abs(Math.log(Math.max(.02f,areaRatio)))*.62f);
  float excessRatio=excessArea/Math.max(.0001f,refArea);float excess=(float)Math.exp(-1.55f*excessRatio);
  float quality=.24f*placement+.18f*direction+.13f*continuity+.13f*widthMass+.12f*excess+.20f*coverage;
  float gate=(float)Math.pow(coverage,1.28);float raw=quality*gate;float calibrated=(float)Math.pow(Math.max(0f,Math.min(1f,raw)),.72f);
  float structure=(float)Math.pow(Math.max(0f,Math.min(1f,coverage*continuity)),.25f);calibrated*=structure;
  // Final diamond-era calibration carried forward: when almost all geometry exists, mediocre
  // placement/direction/continuity cannot coast on coverage alone. Excellent work is untouched.
  if(coverage>.92f){float weakest=Math.min(placement,Math.min(direction,continuity));float need=Math.max(0f,.85f-weakest);float high=(coverage-.92f)/.08f;high=Math.max(0f,Math.min(1f,high));calibrated*=Math.max(.82f,1f-1.15f*high*need);}
  int out=Math.max(0,Math.min(1000,Math.round(1000f*calibrated)));
  if(coverage>.995f&&placement>.995f&&direction>.995f&&Math.abs(areaRatio-1f)<.03f&&excessRatio<.005f)out=1000;
  lastDiag=String.format(java.util.Locale.US,"COV %.1f  PLC %.1f  DIR %.1f  CON %.1f  WID %.1f  EX %.1f",coverage*100,placement*100,direction*100,continuity*100,widthMass*100,excess*100);return out;
 }

 boolean erasedByLater(int t,int index,float x,float y){boolean erased=false;for(int j=index+1;j<done[t].size();j++){Stroke op=done[t].get(j);if(opCovers(op,x,y))erased=op.erase;}return erased;}
 boolean opCovers(Stroke op,float x,float y){float r=op.w*.5f;if(op.p.size()==0)return false;if(op.p.size()==1){Pt q=op.p.get(0);return Math.hypot(x-q.x,y-q.y)<=r;}for(int i=1;i<op.p.size();i++){Pt a=op.p.get(i-1),b=op.p.get(i);if(pointSegDist(x,y,a.x,a.y,b.x,b.y)<=r)return true;}return false;}
 String lastDiag="";
 float pointSegDist(float px,float py,float x1,float y1,float x2,float y2){float dx=x2-x1,dy=y2-y1,l2=dx*dx+dy*dy;if(l2<1e-9f)return (float)Math.hypot(px-x1,py-y1);float t=((px-x1)*dx+(py-y1)*dy)/l2;t=Math.max(0,Math.min(1,t));return (float)Math.hypot(px-(x1+t*dx),py-(y1+t*dy));}
 float sourceDistance(float x,float y){float best=99f;for(float[] g:SRC)best=Math.min(best,pointSegDist(x,y,g[0],g[1],g[2],g[3]));return best;}
 int nearCount(boolean[] from,boolean[] target,int N,int rad){
  int hit=0;
  for(int y=0;y<N;y++)for(int x=0;x<N;x++){int i=y*N+x;if(!from[i])continue;boolean ok=false;
   for(int dy=-rad;dy<=rad&&!ok;dy++)for(int dx=-rad;dx<=rad;dx++){if(dx*dx+dy*dy>rad*rad)continue;int xx=x+dx,yy=y+dy;if(xx>=0&&yy>=0&&xx<N&&yy<N&&target[yy*N+xx]){ok=true;break;}}
   if(ok)hit++;
  }
  return hit;
 }
 int viewMode=1;
 void viewer(Canvas c){float w=getWidth(),h=getHeight();c.drawColor(PAPER);String s=sp.getString("result"+test,null);if(s==null){screen=0;return;}try{JSONObject j=new JSONObject(s);JSONArray a=j.getJSONArray("strokes");text(c,"TEST "+test+"   Accuracy "+j.getInt("score")+" / 1000",w/2,h*.045f,h*.026f,Paint.Align.CENTER);if(j.has("diag"))text(c,j.optString("diag"),w/2,h*.073f,h*.014f,Paint.Align.CENTER);if(test==1)text(c,"DIAG BOUNDARY: 20 cycles + final • stored ops "+a.length(),w/2,h*.094f,h*.013f,Paint.Align.CENTER);RectF area=new RectF(w*.06f,h*.10f,w*.94f,h*.82f);if(viewMode==0){drawStored(c,a,square(area),INK);}else if(viewMode==1){RectF sq=square(area);drawSource(c,sq,Color.BLACK);}else if(viewMode==2){if(w>h){RectF l=square(new RectF(w*.03f,h*.12f,w*.49f,h*.80f)),r=square(new RectF(w*.51f,h*.12f,w*.97f,h*.80f));drawSource(c,l,Color.BLACK);drawStored(c,a,r,INK);}else{RectF u=square(new RectF(w*.10f,h*.11f,w*.90f,h*.43f)),d=square(new RectF(w*.10f,h*.47f,w*.90f,h*.79f));drawSource(c,u,Color.BLACK);drawStored(c,a,d,INK);}}else{RectF sq=square(area);drawSource(c,sq,Color.rgb(185,185,185));drawStored(c,a,sq,INK);}text(c,new String[]{"MY DRAWING","ORIGINAL","SPLIT","OVERLAY"}[viewMode]+"  • tap image to change view",w/2,h*.815f,h*.018f,Paint.Align.CENTER);button(c,new RectF(w*.05f,h*.86f,w*.34f,h*.93f),"BACK");button(c,new RectF(w*.39f,h*.86f,w*.68f,h*.93f),"SAVE PNG");button(c,new RectF(w*.73f,h*.105f,w*.96f,h*.165f),"REDRAW");}catch(Exception e){}}
 RectF square(RectF r){float s=Math.min(r.width(),r.height());return new RectF(r.centerX()-s/2,r.centerY()-s/2,r.centerX()+s/2,r.centerY()+s/2);}
 void drawStored(Canvas c,JSONArray a,RectF full)throws Exception{drawStored(c,a,full,INK);}
 void drawStored(Canvas c,JSONArray a,RectF full,int color)throws Exception{
  int N=Math.max(500,(int)Math.max(full.width(),full.height()));Bitmap bm=Bitmap.createBitmap(N,N,Bitmap.Config.ARGB_8888);Canvas bc=new Canvas(bm);
  for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);int t=o.getInt("t");float cell=N/5f;RectF tr=new RectF((t%5)*cell,(t/5)*cell,(t%5+1)*cell,(t/5+1)*cell);Stroke st=new Stroke(t,(float)o.getDouble("w"));st.erase=o.optBoolean("erase",false);JSONArray pts=o.getJSONArray("p");for(int k=0;k<pts.length();k++){JSONArray v=pts.getJSONArray(k);st.p.add(new Pt((float)v.getDouble(0),(float)v.getDouble(1)));}drawOp(bc,st,tr,color);}
  c.drawBitmap(bm,null,full,p);
 }
 void exportResult(){try{String s=sp.getString("result"+test,null);JSONObject j=new JSONObject(s);JSONArray a=j.getJSONArray("strokes");int N=2400;Bitmap bm=Bitmap.createBitmap(N,N,Bitmap.Config.ARGB_8888);Canvas cc=new Canvas(bm);cc.drawColor(PAPER);drawStored(cc,a,new RectF(0,0,N,N));ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"In-GRID-able_Test_"+test+"_Drawing.png");v.put(MediaStore.Images.Media.MIME_TYPE,"image/png");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/In-GRID-able Drawings");Uri u=getContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);OutputStream os=getContext().getContentResolver().openOutputStream(u);bm.compress(Bitmap.CompressFormat.PNG,100,os);os.close();Toast.makeText(getContext(),"Saved to Gallery",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(getContext(),"Save failed",Toast.LENGTH_SHORT).show();}}
}
