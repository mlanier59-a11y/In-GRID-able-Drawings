# In-GRID-able Drawings Playtest 0.1.98

Scorer 1.0 generalization test #2.

- Replaces the elephant with a leafless branching tree.
- Same scorer and calibration as 0.1.97: no tree-specific scoring adjustments.
- Tests forks/junctions, asymmetry, tapered/variable-width source lines and many local direction changes.
- Keeps the 0.1.96 meaningful-tile classifier and 0.1.97 touch-ownership/result-button fix.
- Fresh save namespace.

Test normally first. Watch especially for blank-looking served tiles and whether branches crossing tile boundaries feel unfairly punished by continuity.
