# In-GRID-able Drawings Diagnostic 0.1.109

Combined state-machine diagnostic.

Test 1 guides 12 steps combining connected strokes, inside-to-outside right-boundary crossings, partial erase, redraw through the erased area, a contained witness stroke, controlled Undo, redraw, a second boundary crossing, and another witness stroke.

STOP immediately and take a screenshot if an older mark disappears unexpectedly.
