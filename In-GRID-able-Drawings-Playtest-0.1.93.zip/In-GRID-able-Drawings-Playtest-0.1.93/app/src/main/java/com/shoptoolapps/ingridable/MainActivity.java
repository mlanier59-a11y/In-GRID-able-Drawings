package com.shoptoolapps.ingridable;

import android.app.*;import android.os.*;import android.content.*;import android.content.res.Configuration;import android.graphics.*;import android.graphics.drawable.*;import android.net.Uri;import android.provider.MediaStore;import android.view.*;import android.widget.*;import org.json.*;import java.io.*;import java.util.*;

public class MainActivity extends Activity{
 GameView game;
 @Override public void onCreate(Bundle b){super.onCreate(b);game=new GameView(this);setContentView(game);}
 @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);game.invalidate();}
}
class Pt{float x,y;Pt(float X,float Y){x=X;y=Y;}}
class Stroke{int tile;float w;ArrayList<Pt> p=new ArrayList<>();Stroke(int t,float W){tile=t;w=W;}}

class GameView extends View{
 Paint p=new Paint(3); Paint line=new Paint(3); final int PAPER=Color.rgb(250,246,232),WOOD=Color.rgb(112,76,49),DARKWOOD=Color.rgb(65,43,31),INK=Color.rgb(28,48,86);
 ArrayList<Stroke>[] done=new ArrayList[25]; ArrayList<Stroke> redo=new ArrayList<>(); Stroke active;
 RectF[] controlHit=new RectF[]{new RectF(),new RectF(),new RectF(),new RectF()}; RectF[] widthHit=new RectF[]{new RectF(),new RectF(),new RectF(),new RectF()};
 RectF gridHit=new RectF(), exitHit=new RectF(), drawBuffer=new RectF(); boolean gridOn=false; int insetBottom=0;
 int screen=0,test=1,tile=0; float widthChoice=.075f; long okLockedUntil=0; boolean okNeedsRelease=false; boolean started=false; RectF ref=new RectF(),draw=new RectF(); SharedPreferences sp; int[] shuffle={12,3,21,7,0,18,5,24,10,1,16,9,22,4,14,6,20,11,2,23,8,17,13,19,15}; int[] playable={2,6,7,8,10,11,13,14,16,17,18,22};
 GameView(Context c){super(c);setBackgroundColor(PAPER);sp=c.getSharedPreferences("playtest0193",0);for(int i=0;i<25;i++)done[i]=new ArrayList<>();setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
 @Override public WindowInsets onApplyWindowInsets(WindowInsets wi){insetBottom=wi.getSystemWindowInsetBottom();invalidate();return wi;}
 void text(Canvas c,String s,float x,float y,float z,Paint.Align a){p.setColor(DARKWOOD);p.setTextSize(z);p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextAlign(a);c.drawText(s,x,y,p);}
 @Override protected void onDraw(Canvas c){super.onDraw(c); if(screen==0)library(c); else if(screen==1)play(c); else viewer(c);}
 void library(Canvas c){float w=getWidth(),h=getHeight();c.drawColor(PAPER);p.setColor(WOOD);c.drawRect(0,0,w,h*.13f,p);text(c,"In-GRID-able Drawings",w/2,h*.075f,h*.034f,Paint.Align.CENTER);text(c,"PLAYTEST 0.1.93",w/2,h*.112f,h*.018f,Paint.Align.CENTER);float top=h*.18f,cardH=h*.20f;
  for(int i=1;i<=3;i++){float y=top+(i-1)*(cardH+h*.035f);p.setColor(Color.WHITE);c.drawRoundRect(w*.08f,y,w*.92f,y+cardH,18,18,p);text(c,"TEST "+i,w*.14f,y+cardH*.22f,h*.025f,Paint.Align.LEFT);for(int k=0;k<i;k++){p.setColor(Color.BLACK);c.drawRect(w*.14f+k*h*.028f,y+cardH*.34f,w*.14f+k*h*.028f+h*.018f,y+cardH*.34f+h*.018f,p);}String saved=sp.getString("result"+i,null); if(saved==null) text(c,"Tap to draw",w*.14f,y+cardH*.78f,h*.022f,Paint.Align.LEFT); else {try{JSONObject j=new JSONObject(saved);text(c,"Finished   Accuracy "+j.getInt("score")+" / 1000",w*.14f,y+cardH*.78f,h*.022f,Paint.Align.LEFT);drawThumb(c,j,w*.68f,y+cardH*.12f,cardH*.76f);}catch(Exception e){}}
  }
 }
 void drawThumb(Canvas c,JSONObject j,float x,float y,float s)throws Exception{p.setColor(PAPER);c.drawRect(x,y,x+s,y+s,p);JSONArray a=j.getJSONArray("strokes");drawStored(c,a,new RectF(x,y,x+s,y+s),Color.rgb(35,72,140));}
 void play(Canvas c){float w=getWidth(),h=getHeight();boolean land=w>h;c.drawColor(PAPER);float rail=land?h*.12f:h*.09f;p.setColor(WOOD);c.drawRect(0,0,w,rail,p);text(c,"TEST "+test+"   REMAINS "+remaining(),w*.04f,rail*.62f,rail*.30f,Paint.Align.LEFT);for(int k=0;k<test;k++){p.setColor(Color.BLACK);c.drawRect(w*.72f+k*rail*.28f,rail*.30f,w*.72f+k*rail*.28f+rail*.18f,rail*.48f,p);}float bottom=h-insetBottom;float controlTop=bottom-Math.max(h*.10f,70);if(land){float top=rail+h*.025f;float availH=controlTop-top-h*.025f;float side=Math.min(availH,w*.39f);float cy=(top+controlTop-h*.025f)/2f;ref.set(w*.025f,cy-side/2,w*.025f+side,cy+side/2);draw.set(w*.975f-side,cy-side/2,w*.975f,cy+side/2);}else{float gap=h*.105f;float top=rail+h*.020f;float availH=controlTop-top-gap-h*.015f;float side=Math.min(w*.82f,(availH-gap)/2f);float left=(w-side)/2f;ref.set(left,top,left+side,top+side);draw.set(left,top+side+gap,left+side,top+side+gap+side);}float buf=draw.width()*.14f;drawBuffer.set(draw.left-buf,draw.top-buf,draw.right+buf,draw.bottom+buf);exitHit.set(w*.91f,rail*.12f,w*.985f,rail*.88f);p.setColor(Color.WHITE);c.drawRect(ref,p);c.drawRect(draw,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(WOOD);c.drawRect(ref,p);c.drawRect(draw,p);p.setStyle(Paint.Style.FILL);button(c,exitHit,"X");
  if(started&&gridOn){drawGrid(c,ref,true);drawGrid(c,draw,true);}
  if(!started){drawScrambled(c,ref);RectF st=land?new RectF(w*.455f,h*.44f,w*.545f,h*.54f):new RectF(w*.34f,ref.bottom+h*.008f,w*.66f,draw.top-h*.008f);button(c,st,"START");}else{drawSourceTile(c,ref,tile);drawCurrent(c,draw,tile);controls(c);}
 }
 void drawScrambled(Canvas c,RectF r){float s=Math.min(r.width(),r.height()),ox=r.centerX()-s/2,oy=r.centerY()-s/2,cs=s/5;for(int pos=0;pos<25;pos++){int src=shuffle[pos];RectF dst=new RectF(ox+(pos%5)*cs,oy+(pos/5)*cs,ox+(pos%5+1)*cs,oy+(pos/5+1)*cs);drawCanonicalTile(c,dst,src);}p.setStyle(Paint.Style.STROKE);p.setColor(Color.rgb(210,200,180));p.setStrokeWidth(1);for(int i=0;i<=5;i++){c.drawLine(ox+i*cs,oy,ox+i*cs,oy+s,p);c.drawLine(ox,oy+i*cs,ox+s,oy+i*cs,p);}p.setStyle(Paint.Style.FILL);}
 void drawCanonicalTile(Canvas c,RectF dst,int t){c.save();c.clipRect(dst);float tw=dst.width(),th=dst.height();RectF full=new RectF(dst.left-(t%5)*tw,dst.top-(t/5)*th,dst.left-(t%5)*tw+tw*5,dst.top-(t/5)*th+th*5);drawSource(c,full,Color.BLACK);c.restore();}
 void drawSourceTile(Canvas c,RectF r,int t){float z=Math.min(r.width(),r.height());RectF sq=new RectF(r.centerX()-z/2,r.centerY()-z/2,r.centerX()+z/2,r.centerY()+z/2);drawCanonicalTile(c,sq,t);}
 void drawSource(Canvas c,RectF r,int color){line.setColor(color);line.setStyle(Paint.Style.STROKE);line.setStrokeCap(Paint.Cap.ROUND);line.setStrokeJoin(Paint.Join.ROUND);line.setStrokeWidth(r.width()*.015f);Path q=new Path();q.moveTo(r.left+r.width()*.50f,r.top+r.height()*.10f);q.lineTo(r.left+r.width()*.88f,r.top+r.height()*.50f);q.lineTo(r.left+r.width()*.50f,r.top+r.height()*.90f);q.lineTo(r.left+r.width()*.12f,r.top+r.height()*.50f);q.close();c.drawPath(q,line);line.setStyle(Paint.Style.FILL);}
 void drawCurrent(Canvas c,RectF r,int t){for(Stroke s:done[t])drawStroke(c,s,r,INK);if(active!=null)drawStroke(c,active,r,INK);}
 void drawStroke(Canvas c,Stroke s,RectF r,int col){if(s.p.size()<1)return;c.save();c.clipRect(r);line.setColor(col);line.setStyle(Paint.Style.STROKE);line.setStrokeCap(Paint.Cap.ROUND);line.setStrokeJoin(Paint.Join.ROUND);line.setStrokeWidth(Math.max(2,s.w*r.width()));Path q=new Path();Pt a=s.p.get(0);q.moveTo(r.left+a.x*r.width(),r.top+a.y*r.height());for(int i=1;i<s.p.size();i++){a=s.p.get(i);q.lineTo(r.left+a.x*r.width(),r.top+a.y*r.height());}if(s.p.size()==1)c.drawPoint(r.left+a.x*r.width(),r.top+a.y*r.height(),line);else c.drawPath(q,line);line.setStyle(Paint.Style.FILL);c.restore();}
 void controls(Canvas c){float w=getWidth(),h=getHeight();boolean land=w>h;float bottom=h-insetBottom;float barH=Math.max(h*.10f,70);float top=bottom-barH;p.setColor(WOOD);c.drawRect(0,top,w,bottom,p);String[] a={"UNDO","REDO","WIPE","OK"};for(int i=0;i<4;i++){controlHit[i].set(w*(.02f+i*.245f),top+barH*.12f,w*(.235f+i*.245f),bottom-barH*.12f);button(c,controlHit[i],a[i]);}
  float[] ws={.020f,.040f,.075f,.120f};if(land){float cx=w*.50f,cy=(ref.top+ref.bottom)/2f;float step=Math.min(h*.11f,ref.height()*.18f);for(int i=0;i<4;i++){float yy=cy+(i-1.5f)*step;widthHit[i].set(cx-w*.035f,yy-step*.35f,cx+w*.035f,yy+step*.35f);p.setColor(i==widthIndex()?Color.rgb(245,220,160):WOOD);c.drawCircle(cx,yy,Math.min(w*.018f,step*.25f),p);line.setColor(DARKWOOD);line.setStrokeWidth(Math.max(2,ws[i]*draw.width()));c.drawLine(cx-w*.020f,yy,cx+w*.020f,yy,line);}gridHit.set(w*.455f,ref.bottom-h*.075f,w*.545f,ref.bottom-h*.015f);}else{float cy=(ref.bottom+draw.top)/2f;float step=w*.105f;float first=w*.32f;for(int i=0;i<4;i++){float xx=first+i*step;widthHit[i].set(xx-step*.38f,cy-h*.025f,xx+step*.38f,cy+h*.025f);p.setColor(i==widthIndex()?Color.rgb(245,220,160):WOOD);c.drawCircle(xx,cy,Math.min(w*.020f,h*.018f),p);line.setColor(DARKWOOD);line.setStrokeWidth(Math.max(2,ws[i]*draw.width()));c.drawLine(xx-w*.025f,cy,xx+w*.025f,cy,line);}gridHit.set(w*.04f,cy-h*.030f,w*.22f,cy+h*.030f);}button(c,gridHit,gridOn?"GRID ON":"GRID");}
 void drawGrid(Canvas c,RectF r,boolean buffer){RectF g=new RectF(r);if(buffer){float b=Math.min(r.width(),r.height())*.14f;g.inset(-b,-b);}p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);p.setColor(Color.argb(buffer?70:95,60,105,150));for(int i=0;i<=6;i++){float x=g.left+g.width()*i/6f,y=g.top+g.height()*i/6f;c.drawLine(x,g.top,x,g.bottom,p);c.drawLine(g.left,y,g.right,y,p);}p.setStyle(Paint.Style.FILL);}
 int widthIndex(){float[] a={.020f,.040f,.075f,.120f};int best=0;for(int i=1;i<4;i++)if(Math.abs(a[i]-widthChoice)<Math.abs(a[best]-widthChoice))best=i;return best;}
 void button(Canvas c,RectF r,String s){p.setColor(DARKWOOD);c.drawRoundRect(r,12,12,p);p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(r.height()*.38f);c.drawText(s,r.centerX(),r.centerY()+r.height()*.14f,p);}
 @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();int action=e.getActionMasked();if(action==MotionEvent.ACTION_UP&&okNeedsRelease&&SystemClock.uptimeMillis()>=okLockedUntil)okNeedsRelease=false;if(screen==0&&action==MotionEvent.ACTION_UP){float top=h*.18f,cardH=h*.20f;for(int i=1;i<=3;i++){float yy=top+(i-1)*(cardH+h*.035f);if(y>=yy&&y<=yy+cardH){test=i;if(sp.contains("result"+i)){screen=2;}else{resetPlay();screen=1;}invalidate();return true;}}}
  else if(screen==1){if(action==MotionEvent.ACTION_UP&&exitHit.contains(x,y)){saveProgress();((Activity)getContext()).finishAndRemoveTask();return true;}if(!started&&action==MotionEvent.ACTION_UP&&startTouchHit(x,y)){started=true;tile=playable[0];okLockedUntil=SystemClock.uptimeMillis()+350;okNeedsRelease=true;saveProgress();invalidate();return true;}if(started){if(action==MotionEvent.ACTION_UP&&gridHit.contains(x,y)){gridOn=!gridOn;invalidate();return true;}if(action==MotionEvent.ACTION_UP){for(int i=0;i<4;i++)if(widthHit[i].contains(x,y)){widthChoice=new float[]{.020f,.040f,.075f,.120f}[i];invalidate();return true;}for(int i=0;i<4;i++)if(controlHit[i].contains(x,y)){if(i==0&&done[tile].size()>0){redo.add(done[tile].remove(done[tile].size()-1));saveProgress();}else if(i==1&&redo.size()>0){done[tile].add(redo.remove(redo.size()-1));saveProgress();}else if(i==2){done[tile].clear();redo.clear();active=null;saveProgress();}else if(i==3){if(!okNeedsRelease&&SystemClock.uptimeMillis()>=okLockedUntil){active=null;commitTile();}}invalidate();return true;}}
   if(action==MotionEvent.ACTION_DOWN&&drawBuffer.contains(x,y)){float nx=(x-draw.left)/draw.width(),ny=(y-draw.top)/draw.height();active=new Stroke(tile,widthChoice);active.p.add(new Pt(nx,ny));getParent().requestDisallowInterceptTouchEvent(true);invalidate();return true;}
   if(active!=null&&(action==MotionEvent.ACTION_MOVE||action==MotionEvent.ACTION_UP)){float nx=(x-draw.left)/draw.width(),ny=(y-draw.top)/draw.height();active.p.add(new Pt(nx,ny));if(action==MotionEvent.ACTION_UP){done[tile].add(active);active=null;redo.clear();saveProgress();getParent().requestDisallowInterceptTouchEvent(false);}invalidate();return true;}
   if(action==MotionEvent.ACTION_CANCEL&&active!=null){done[tile].add(active);active=null;redo.clear();saveProgress();getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;}}
  } else if(screen==2&&action==MotionEvent.ACTION_UP){if(y>h*.86f){if(x<w*.33f){screen=0;}else if(x<w*.66f){exportResult();}else{resetPlay();screen=1;}invalidate();return true;}viewMode=(viewMode+1)%4;invalidate();return true;}return true;}
 boolean startTouchHit(float x,float y){float w=getWidth(),h=getHeight();boolean land=w>h;if(land)return x>w*.455f&&x<w*.545f&&y>h*.40f&&y<h*.58f;return x>w*.34f&&x<w*.66f&&y>ref.bottom&&y<draw.top;}
 void resetPlay(){tile=playable[0];started=false;active=null;redo.clear();for(int i=0;i<25;i++)done[i].clear();loadProgress();}
 int playableIndex(int t){for(int i=0;i<playable.length;i++)if(playable[i]==t)return i;return -1;}
 int remaining(){int i=playableIndex(tile);return started&&i>=0?playable.length-i:playable.length;}
 void commitTile(){active=null;redo.clear();int i=playableIndex(tile);if(i>=0&&i<playable.length-1){tile=playable[i+1];okLockedUntil=SystemClock.uptimeMillis()+500;okNeedsRelease=true;saveProgress();}else finishPuzzle();}
 void saveProgress(){try{JSONObject j=serialize(false,0);j.put("tile",tile);j.put("started",started);sp.edit().putString("progress"+test,j.toString()).apply();}catch(Exception e){}}
 void loadProgress(){String s=sp.getString("progress"+test,null);if(s==null)return;try{JSONObject j=new JSONObject(s);tile=j.getInt("tile");started=j.getBoolean("started");loadStrokes(j.getJSONArray("strokes"));}catch(Exception e){}}
 JSONObject serialize(boolean all,int score)throws Exception{JSONObject j=new JSONObject();j.put("score",score);JSONArray a=new JSONArray();for(int t=0;t<25;t++)for(Stroke s:done[t]){JSONObject o=new JSONObject();o.put("t",t);o.put("w",s.w);JSONArray pts=new JSONArray();for(Pt q:s.p){JSONArray v=new JSONArray();v.put(q.x);v.put(q.y);pts.put(v);}o.put("p",pts);a.put(o);}j.put("strokes",a);return j;}
 void loadStrokes(JSONArray a)throws Exception{for(int i=0;i<25;i++)done[i].clear();for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Stroke s=new Stroke(o.getInt("t"),(float)o.getDouble("w"));JSONArray pts=o.getJSONArray("p");for(int k=0;k<pts.length();k++){JSONArray v=pts.getJSONArray(k);s.p.add(new Pt((float)v.getDouble(0),(float)v.getDouble(1)));}done[s.tile].add(s);}}
 void finishPuzzle(){active=null;redo.clear();int score=score();try{JSONObject j=serialize(true,score);j.put("scorer","1.0-vector");j.put("diag",lastDiag);sp.edit().putString("result"+test,j.toString()).remove("progress"+test).apply();}catch(Exception e){}screen=2;viewMode=1;}
 int score(){
  // Scorer 1.0 playtest: vector-centerline inspection.  Each gauge has one job:
  // coverage, placement, direction, continuity, width/mass, and reference-relative excess.
  ArrayList<float[]> segs=new ArrayList<>();
  float userArea=0f, excessArea=0f;
  for(int t=0;t<25;t++)for(Stroke st:done[t]){
   float ox=(t%5)/5f,oy=(t/5)/5f,sw=st.w/5f;
   if(st.p.size()==1){Pt q=st.p.get(0);float x=ox+q.x/5f,y=oy+q.y/5f;segs.add(new float[]{x,y,x,y,sw});userArea+=3.14159f*sw*sw*.25f;continue;}
   for(int i=1;i<st.p.size();i++){Pt a=st.p.get(i-1),b=st.p.get(i);float x1=ox+a.x/5f,y1=oy+a.y/5f,x2=ox+b.x/5f,y2=oy+b.y/5f;float len=(float)Math.hypot(x2-x1,y2-y1);if(len<.00015f)continue;segs.add(new float[]{x1,y1,x2,y2,sw});userArea+=len*sw;float mx=(x1+x2)*.5f,my=(y1+y2)*.5f;if(sourceDistance(mx,my)>.030f)excessArea+=len*sw;}
  }
  if(segs.size()==0){lastDiag="COV 0  PLC 0  DIR 0  CON 0  WID 0  EX 0";return 0;}
  final int S=1600; int covered=0; float placeSum=0,dirSum=0; boolean[] hit=new boolean[S];
  for(int i=0;i<S;i++){
   float u=(i+.5f)/S*4f;int side=Math.min(3,(int)u);float f=u-side;
   float[] A=srcPoint(side,0),B=srcPoint(side,1);float x=A[0]+(B[0]-A[0])*f,y=A[1]+(B[1]-A[1])*f;
   float best=99f,bdir=0f;
   for(float[] g:segs){float d=pointSegDist(x,y,g[0],g[1],g[2],g[3]);if(d<best){best=d;float sx=B[0]-A[0],sy=B[1]-A[1],gx=g[2]-g[0],gy=g[3]-g[1];float sl=(float)Math.hypot(sx,sy),gl=(float)Math.hypot(gx,gy);bdir=gl<.0001f?0f:Math.abs((sx*gx+sy*gy)/(sl*gl));}}
   float pc=best<=.004f?1f:Math.max(0f,1f-(best-.004f)/.030f);placeSum+=pc;
   if(best<=.022f){covered++;hit[i]=true;dirSum+=bdir;}
  }
  float coverage=covered/(float)S,placement=placeSum/S,direction=covered==0?0:dirSum/covered;
  // Continuity: reward long uninterrupted runs along the required source centerline.
  int transitions=0;for(int i=1;i<S;i++)if(hit[i]!=hit[i-1])transitions++;float continuity=coverage*(float)Math.exp(-transitions/18f);
  float refLen=0f;for(int k=0;k<4;k++){float[] A=srcPoint(k,0),B=srcPoint(k,1);refLen+=Math.hypot(B[0]-A[0],B[1]-A[1]);}float refArea=refLen*.015f;
  float areaRatio=userArea/refArea;float widthMass=(float)Math.exp(-Math.abs(Math.log(Math.max(.02f,areaRatio)))*.62f);
  float excessRatio=excessArea/refArea;float excess=(float)Math.exp(-1.55f*excessRatio);
  // Coverage is foundational: beautiful work on half the picture cannot buy back the missing half.
  float quality=.24f*placement+.18f*direction+.13f*continuity+.13f*widthMass+.12f*excess+.20f*coverage;
  float gate=(float)Math.pow(coverage,1.28);float raw=quality*gate;
  // Gentle calibration uses the 0-1000 range without creating a hard threshold.
  float calibrated=(float)Math.pow(Math.max(0f,Math.min(1f,raw)),.72f);
  int out=Math.max(0,Math.min(1000,Math.round(1000f*calibrated)));
  if(coverage>.995f&&placement>.995f&&direction>.995f&&Math.abs(areaRatio-1f)<.03f&&excessRatio<.005f)out=1000;
  lastDiag=String.format(java.util.Locale.US,"COV %.0f  PLC %.0f  DIR %.0f  CON %.0f  WID %.0f  EX %.0f",coverage*100,placement*100,direction*100,continuity*100,widthMass*100,excess*100);
  return out;
 }
 String lastDiag="";
 float[] srcPoint(int side,int end){float[][] v={{.50f,.10f},{.88f,.50f},{.50f,.90f},{.12f,.50f},{.50f,.10f}};return v[side+end];}
 float pointSegDist(float px,float py,float x1,float y1,float x2,float y2){float dx=x2-x1,dy=y2-y1,l2=dx*dx+dy*dy;if(l2<1e-9f)return (float)Math.hypot(px-x1,py-y1);float t=((px-x1)*dx+(py-y1)*dy)/l2;t=Math.max(0,Math.min(1,t));return (float)Math.hypot(px-(x1+t*dx),py-(y1+t*dy));}
 float sourceDistance(float x,float y){float best=99f;for(int k=0;k<4;k++){float[] A=srcPoint(k,0),B=srcPoint(k,1);best=Math.min(best,pointSegDist(x,y,A[0],A[1],B[0],B[1]));}return best;}
 int nearCount(boolean[] from,boolean[] target,int N,int rad){
  int hit=0;
  for(int y=0;y<N;y++)for(int x=0;x<N;x++){int i=y*N+x;if(!from[i])continue;boolean ok=false;
   for(int dy=-rad;dy<=rad&&!ok;dy++)for(int dx=-rad;dx<=rad;dx++){if(dx*dx+dy*dy>rad*rad)continue;int xx=x+dx,yy=y+dy;if(xx>=0&&yy>=0&&xx<N&&yy<N&&target[yy*N+xx]){ok=true;break;}}
   if(ok)hit++;
  }
  return hit;
 }
 int viewMode=1;
 void viewer(Canvas c){float w=getWidth(),h=getHeight();c.drawColor(PAPER);String s=sp.getString("result"+test,null);if(s==null){screen=0;return;}try{JSONObject j=new JSONObject(s);JSONArray a=j.getJSONArray("strokes");text(c,"TEST "+test+"   Accuracy "+j.getInt("score")+" / 1000",w/2,h*.045f,h*.026f,Paint.Align.CENTER);if(j.has("diag"))text(c,j.optString("diag"),w/2,h*.073f,h*.014f,Paint.Align.CENTER);RectF area=new RectF(w*.06f,h*.10f,w*.94f,h*.82f);if(viewMode==0){drawStored(c,a,square(area),INK);}else if(viewMode==1){RectF sq=square(area);drawSource(c,sq,Color.BLACK);}else if(viewMode==2){if(w>h){RectF l=square(new RectF(w*.03f,h*.12f,w*.49f,h*.80f)),r=square(new RectF(w*.51f,h*.12f,w*.97f,h*.80f));drawSource(c,l,Color.BLACK);drawStored(c,a,r,INK);}else{RectF u=square(new RectF(w*.10f,h*.11f,w*.90f,h*.43f)),d=square(new RectF(w*.10f,h*.47f,w*.90f,h*.79f));drawSource(c,u,Color.BLACK);drawStored(c,a,d,INK);}}else{RectF sq=square(area);drawSource(c,sq,Color.rgb(185,185,185));drawStored(c,a,sq,INK);}text(c,new String[]{"MY DRAWING","ORIGINAL","SPLIT","OVERLAY"}[viewMode]+"  • tap image to change view",w/2,h*.85f,h*.018f,Paint.Align.CENTER);button(c,new RectF(w*.03f,h*.89f,w*.30f,h*.97f),"BACK");button(c,new RectF(w*.365f,h*.89f,w*.635f,h*.97f),"SAVE PNG");button(c,new RectF(w*.70f,h*.89f,w*.97f,h*.97f),"REDRAW");}catch(Exception e){}}
 RectF square(RectF r){float s=Math.min(r.width(),r.height());return new RectF(r.centerX()-s/2,r.centerY()-s/2,r.centerX()+s/2,r.centerY()+s/2);}
 void drawStored(Canvas c,JSONArray a,RectF full)throws Exception{drawStored(c,a,full,INK);}
 void drawStored(Canvas c,JSONArray a,RectF full,int color)throws Exception{for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);int t=o.getInt("t");RectF tr=new RectF(full.left+(t%5)*full.width()/5,full.top+(t/5)*full.height()/5,full.left+(t%5+1)*full.width()/5,full.top+(t/5+1)*full.height()/5);Stroke st=new Stroke(t,(float)o.getDouble("w"));JSONArray pts=o.getJSONArray("p");for(int k=0;k<pts.length();k++){JSONArray v=pts.getJSONArray(k);st.p.add(new Pt((float)v.getDouble(0),(float)v.getDouble(1)));}drawStroke(c,st,tr,color);}}
 void exportResult(){try{String s=sp.getString("result"+test,null);JSONObject j=new JSONObject(s);JSONArray a=j.getJSONArray("strokes");int N=2400;Bitmap bm=Bitmap.createBitmap(N,N,Bitmap.Config.ARGB_8888);Canvas cc=new Canvas(bm);cc.drawColor(PAPER);drawStored(cc,a,new RectF(0,0,N,N));ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"In-GRID-able_Test_"+test+"_Drawing.png");v.put(MediaStore.Images.Media.MIME_TYPE,"image/png");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/In-GRID-able Drawings");Uri u=getContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);OutputStream os=getContext().getContentResolver().openOutputStream(u);bm.compress(Bitmap.CompressFormat.PNG,100,os);os.close();Toast.makeText(getContext(),"Saved to Gallery",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(getContext(),"Save failed",Toast.LENGTH_SHORT).show();}}
}
