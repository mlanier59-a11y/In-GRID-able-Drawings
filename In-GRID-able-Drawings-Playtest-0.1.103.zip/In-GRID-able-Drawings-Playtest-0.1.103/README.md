# In-GRID-able Drawings Playtest 0.1.103

Filled-area + linework gameplay specimen.

- New recognizable bird-on-a-branch source.
- Broad overlapping source strokes create solid-looking body/head/wing masses plus thin contour, feather, leg, beak and branch linework.
- Scorer 1.0 formulas/calibration are unchanged from 0.1.99.
- Canonical master grid retained; grid starts ON during served-tile gameplay.
- Fixed shuffle, blank/meaningless tile skipping, touch ownership, Undo/Redo/Wipe/OK, save PNG, Original/My Drawing/Split/Overlay review retained.
- Fresh 0.1.103 save namespace so prior playtests cannot contaminate this run.

Purpose: resume real gameplay after dot-gauge diagnostics and challenge the frozen scorer with visual mass + linework.
